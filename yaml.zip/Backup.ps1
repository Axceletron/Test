﻿$Folder = Get-Date -UFormat "%d-%m-%Y"
CD D:\

$path = "D:\Backup"
If(!(test-path $path))
{
New-Item -ItemType Directory -Force -Path $path
}
cd $path
New-Item -ItemType Directory -Path $Folder 
$backupF = $path + "\"+ $Folder


Move-Item D:\Jboss\module.xml $backupF